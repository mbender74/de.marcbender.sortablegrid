See the /testapp project for details!
